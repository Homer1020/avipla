<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="mt-4">Dashboard</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: "success",
            title: "<?php echo e(session('success')); ?>"
        });
    </script>
  <?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\avipla\resources\views/dashboard/index.blade.php ENDPATH**/ ?>