<!-- Nav tabs -->
<ul class="nav nav-tabs nav-fill mb-3" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#business-data" type="button"
            role="tab" aria-controls="home" aria-selected="true">Paso #1</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button"
            role="tab" aria-controls="profile" aria-selected="false">Paso #2</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="messages-tab" data-bs-toggle="tab" data-bs-target="#messages" type="button"
            role="tab" aria-controls="messages" aria-selected="false">Paso #3</button>
    </li>
</ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="business-data" role="tabpanel" tabindex="0">
        <?php echo $__env->make('afiliados.form.business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="tab-pane" id="profile" role="tabpanel" tabindex="0">
        <?php echo $__env->make('afiliados.form.personal-without-names', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="tab-pane" id="messages" role="tabpanel" tabindex="0">
        <?php echo $__env->make('afiliados.form.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex align-items-center mt-5">
            <input type="submit" value="Registrar" class="btn btn-primary me-4">
            <a href="<?php echo e(route('auth.loginForm')); ?>">Iniciar sesion</a>
        </div>
    </div>
</div><?php /**PATH D:\laragon\www\avipla\resources\views/afiliados/form.blade.php ENDPATH**/ ?>