<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'error'         => false,
    'id'            => '',
    'name'          => '',
    'placeholder'   => '',
    'label'         => '',
    'autofocus'     => false,
    'required'      => false,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'error'         => false,
    'id'            => '',
    'name'          => '',
    'placeholder'   => '',
    'label'         => '',
    'autofocus'     => false,
    'required'      => false,
]); ?>
<?php foreach (array_filter(([
    'error'         => false,
    'id'            => '',
    'name'          => '',
    'placeholder'   => '',
    'label'         => '',
    'autofocus'     => false,
    'required'      => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="mb-3">
    <label for="<?php echo e($id); ?>" class="form-label"><?php echo e($label); ?> <?php echo $required ? '<span class="text-danger fw-bold">*</span>' : ''; ?></label>
    <select
        class="form-select <?php echo e($error ? 'is-invalid' : ''); ?>"
        id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>"
        <?php if($autofocus): ?> autofocus <?php endif; ?>
        <?php if($required): ?> required <?php endif; ?>
    ><?php echo e($slot); ?></select>
    <?php if($error): ?>
        <div class="invalid-feedback"><?php echo e($error); ?></div>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\avipla\resources\views/components/forms/select.blade.php ENDPATH**/ ?>