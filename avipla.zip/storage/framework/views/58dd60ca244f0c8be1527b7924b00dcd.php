<?php $__env->startSection('title', 'Detalle de ' . $afiliado->razon_social); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="mt-4">Detalle de <?php echo e($afiliado->razon_social); ?></h1>
  <ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('afiliados.index')); ?>">Afiliados</a></li>
    <li class="breadcrumb-item active">Detalle</li>
  </ol>

  <div class="row mb-4">
    <div class="col-lg-6">
      <p class="fw-bold text-uppercase text-muted">Datos de la empresa</p>
      <ul class="list-group mb-3">
        <li class="list-group-item">
          <span class="fw-bold">Razón social: </span>
          <?php echo e($afiliado->razon_social); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">RIF: </span>
          <?php echo e($afiliado->rif); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Página web: </span>
          <a href="<?php echo e($afiliado->pagina_web); ?>"><?php echo e($afiliado->pagina_web); ?></a>
        </li>
        <li class="list-group-item">
          <span class="fw-bold">Actividad principal: </span>
          <?php echo e($afiliado->actividad->actividad); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Relaciones de comercio exterior: </span>
          <?php echo e($afiliado->relacion_comercio_exterior); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Estado: </span>
          <?php if($afiliado->estado): ?>
            <span class="badge bg-success">Activo</span>
          <?php else: ?>
            <span class="badge bg-success">Inactivo</span>
          <?php endif; ?>
        </li>
      </ul>
      <p class="fw-bold text-uppercase text-muted">Direcciones</p>
      <ul class="list-group mb-3">
        <li class="list-group-item">
          <span class="fw-bold">Dirección (oficina): </span>
          <?php echo e($afiliado->direccion->direccion_oficina); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Ciudad / estado (oficina): </span>
          <?php echo e($afiliado->direccion->ciudad_oficina); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Teléfono (oficina): </span>
          <?php echo e($afiliado->direccion->telefono_oficina); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Dirección (planta): </span>
          <?php echo e($afiliado->direccion->direccion_planta); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Ciudad / estado (planta): </span>
          <?php echo e($afiliado->direccion->ciudad_planta); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Teléfono (planta): </span>
          <?php echo e($afiliado->direccion->telefono_planta); ?>

        </li>
      </ul>

      <p class="fw-bold text-uppercase text-muted">Principales materias primas utilizadas</p>
      <ul class="list-group mb-3">
        <?php $__currentLoopData = $afiliado->materias_primas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia_prima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item">
            <?php echo e($materia_prima->materia_prima); ?>

          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <p class="fw-bold text-uppercase text-muted">Servicios prestados</p>
      <ul class="list-group mb-3">
        <?php $__currentLoopData = $afiliado->servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item">
            <?php echo e($servicio->nombre_servicio); ?>

          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <p class="fw-bold text-uppercase text-muted">Empresas asociadas a AVIPLA que la refieren</p>
      <ul class="list-group mb-3">
        <?php $__empty_1 = true; $__currentLoopData = $afiliado->referencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <li class="list-group-item">
            <?php echo e($referencia->razon_social); ?>

          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <li class="list-group-item list-group-item-info">
            Sin referencias
          </li>
        <?php endif; ?>
      </ul>
    </div>
    <div class="col-lg-6">
      <p class="fw-bold text-uppercase text-muted">Datos del encargado</p>
      <ul class="list-group mb-3">
        <?php if($afiliado->user()->exists()): ?>
        <?php
          $afiliado->load('user');    
        ?>
          <li class="list-group-item"><span class="fw-bold">Encargado:</span> <?php echo e($afiliado->user->name); ?></li>
          <li class="list-group-item"><span class="fw-bold">Correo del encargado:</span> <a href="mailto:<?php echo e($afiliado->user->email); ?>"><?php echo e($afiliado->user->email); ?></a></li>
        <?php else: ?>
          <li class="list-group-item">
            <span class="fw-bold">Solicitar registro por correo:</span>
            <form action="<?php echo e(route('afiliados.sendConfirmationEmail', $afiliado)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-success mt-2">
                <i class="fa fa-envelope"></i>
                Enviar correo
              </button>
            </form>
            <?php if($afiliado->confirmation_code): ?>
              <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
                  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                </symbol>
                <symbol id="info-fill" fill="currentColor" viewBox="0 0 16 16">
                  <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
                </symbol>
                <symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                </symbol>
              </svg>
              <div class="alert alert-primary d-flex align-items-center mt-2 mb-0" role="alert">
                <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Info:"><use xlink:href="#info-fill"/></svg>
                <div>
                  Ya se envió un enlace pare el registro.
                </div>
              </div>
            <?php endif; ?>
          </li>
        <?php endif; ?>
      </ul>
      <p class="fw-bold text-uppercase text-muted">Datos del personal</p>
      <ul class="list-group mb-3">
        <li class="list-group-item">
          <span class="fw-bold">Correo del presidente: </span>
          <?php echo e($afiliado->personal->correo_presidente); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del gerente general: </span>
          <?php echo e($afiliado->personal->correo_gerente_general); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del gerente de compras: </span>
          <?php echo e($afiliado->personal->correo_gerente_compras); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del gerente de mercadeo y/o ventas: </span>
          <?php echo e($afiliado->personal->correo_gerente_marketing_ventas); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del gerente de planta: </span>
          <?php echo e($afiliado->personal->correo_gerente_planta); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del gerente de recursos humanos: </span>
          <?php echo e($afiliado->personal->correo_gerente_recursos_humanos); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del administrador: </span>
          <?php echo e($afiliado->personal->correo_administrador); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del gerente de exportaciones: </span>
          <?php echo e($afiliado->personal->correo_gerente_exportaciones); ?>

        </li>
        <li class="list-group-item">
          <span class="fw-bold">Correo del representante ante AVIPLA: </span>
          <?php echo e($afiliado->personal->correo_representante_avipla); ?>

        </li>
      </ul>

      <p class="fw-bold text-uppercase text-muted">Linea de productos</p>
      <ul class="list-group mb-3">
        <?php $__currentLoopData = $afiliado->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item">
            <span class="fw-bold">Producto: </span>
            <?php echo e($producto->nombre); ?>

            <br>
            <span class="fw-bold">Producción total mensual (TM): </span>
            <?php echo e($producto->pivot->produccion_total_mensual); ?>

            <br>
            <span class="fw-bold">Porcentaje destinados a exportación: </span>
            <?php echo e($producto->pivot->porcentage_exportacion); ?>

            <br>
            <span class="fw-bold">Mercados de importación / exportación: </span>
            <?php echo e($producto->pivot->mercado_exportacion); ?>

          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: "success",
            title: "<?php echo e(session('success')); ?>"
        });
    </script>
  <?php endif; ?>

  <script>
    function submitAfterConfirm(form) {
      Swal.fire({
        title: "¿Estas seguro?",
        text: "¡Esta acción no se puede revertir!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Si, eliminalo!",
        cancelButtonText: "Cancelar"
      }).then((result) => {
        if (result.isConfirmed) form.submit()
      })
    }
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avipla\resources\views/afiliados/show.blade.php ENDPATH**/ ?>