<?php $__env->startSection('title', 'Afiliados'); ?>
<?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="mt-4">Noticias</h1>
  <ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Noticias</li>
  </ol>
  <div class="mb-4">
    <a href="<?php echo e(route('noticias.create')); ?>" class="btn btn-primary">Nueva noticia</a>
  </div>

  <div class="mb-4 card">
    <div class="card-body">
      <table class="table table-bordered w-100" id="afiliados-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Fecha</th>
            <th>Categoría</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>#<?php echo e($noticia->id); ?></td>
              <td>
                <a href="<?php echo e(route('noticias.show', $noticia)); ?>" target="_blank">
                  <?php echo e($noticia->titulo); ?>

                </a>
              </td>
              <td><?php echo e($noticia->created_at); ?></td>
              <td>
                <?php if($noticia->categoria): ?>
                  <span class="badge bg-primary"><?php echo e($noticia->categoria->display_name); ?></span>
                <?php else: ?>
                  <span class="badge bg-secondary">Sin categoría</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if($noticia->estatus === 'PUBLISHED'): ?>
                  <span class="bg-success badge"><?php echo e($noticia->estatus); ?></span>
                <?php else: ?>
                  <span class="bg-secondary badge"><?php echo e($noticia->estatus); ?></span>
                <?php endif; ?> 
              </td>
              <td style="white-space: nowrap">
                <a href="<?php echo e(route('noticias.edit', $noticia)); ?>" class="btn btn-warning">
                  <i class="fa fa-pen"></i>
                  Editar
                </a>
                <form class="d-inline-block" action="<?php echo e(route('noticias.destroy', $noticia)); ?>" onsubmit="submitAfterConfirm(event.target); return false" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">
                    <i class="fa fa-trash"></i>
                    Eliminar
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="<?php echo e(asset('assets/css/datatables.min.js')); ?>"></script>

  <?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: "success",
            title: "<?php echo e(session('success')); ?>"
        });
    </script>
  <?php endif; ?>

  <script>
    function submitAfterConfirm(form) {
      Swal.fire({
        title: "¿Estas seguro?",
        text: "¡Esta acción no se puede revertir!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Si, eliminalo!",
        cancelButtonText: "Cancelar"
      }).then((result) => {
        if (result.isConfirmed) form.submit()
      })
    }

    new DataTable('#afiliados-table', {
      columnDefs: [
        { orderable: false, targets: 5 },
      ],
      order: false,
      language: {
        // url: '//cdn.datatables.net/plug-ins/2.0.8/i18n/es-ES.json',
      }
    })
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avipla\resources\views/noticias/index.blade.php ENDPATH**/ ?>