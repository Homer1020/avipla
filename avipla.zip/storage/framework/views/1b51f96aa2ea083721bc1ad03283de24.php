<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AVIPLA | Registro</title>
  <!-- BOOTSTRAP -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <!-- OWL CAROUSEL -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">
  <!-- OWL CAROUSEL THEME -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.css')); ?>">
  <!-- SELECT2 -->
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <!-- SELECT2 BOOTSTRAP THEME -->
  <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">
</head>

<body class="bg-secondary">
  <main class="auth-layout">
    <div class="container my-5">
      <div class="row justify-content-center">
        <div class="col-lg-11">
          <div class="card shadow">
            <div class="card-body p-4">
              <h1 class="fs-3 fw-bold text-primary text-center mb-4 text-uppercase">Crear cuenta</h1>

              <form novalidate action="<?php echo e(route('auth.register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="confirmation_code" value="<?php echo e($solicitud->confirmation_code); ?>">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs nav-fill mb-3" id="myTab" role="tablist">
                  <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#business-data"
                      type="button" role="tab" aria-controls="home" aria-selected="true">Datos de la empresa</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                      type="button" role="tab" aria-controls="profile" aria-selected="false">Actividades y personal</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="messages-tab" data-bs-toggle="tab" data-bs-target="#messages"
                      type="button" role="tab" aria-controls="messages" aria-selected="false">Productos y servicios</button>
                  </li>
                  <li class="nav-item" role="presentation">
                    <button class="nav-link" id="final-tab" data-bs-toggle="tab" data-bs-target="#final"
                      type="button" role="tab" aria-controls="final" aria-selected="false">Registro de encargado</button>
                  </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                  <div class="tab-pane active" id="business-data" role="tabpanel" tabindex="0">
                    <?php echo $__env->make('afiliados.form.business', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div class="tab-pane" id="profile" role="tabpanel" tabindex="0">
                    <?php echo $__env->make('afiliados.form.personal-without-names', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div class="tab-pane" id="messages" role="tabpanel" tabindex="0">
                    <?php echo $__env->make('afiliados.form.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div class="tab-pane" id="final" role="tabpanel" tabindex="0">
                    <p class="fw-bold text-muted text-uppercase">Datos del encargado</p>
                    <div class="row">
                      <div class="col-lg-6">
                        <!-- name -->
                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['placeholder' => 'John Doe','name' => 'name','id' => 'name','label' => 'Nombre del encargado:','value' => old('name'),'error' => $errors->first('name'),'autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'John Doe','name' => 'name','id' => 'name','label' => 'Nombre del encargado:','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name')),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('name')),'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                        <!-- /name -->
                      </div>
                      <div class="col-lg-6">
                        <!-- correo -->
                        <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'email','placeholder' => 'johndoe@gmail.com','name' => 'email','id' => 'email','label' => 'Correo del encargado:','value' => old('email', $solicitud->correo),'error' => $errors->first('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'email','placeholder' => 'johndoe@gmail.com','name' => 'email','id' => 'email','label' => 'Correo del encargado:','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email', $solicitud->correo)),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('email'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                        <!-- /correo -->
                      </div>
                    </div>

                    <!-- password -->
                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'password','placeholder' => '********','name' => 'password','id' => 'password','label' => 'Contraseña:','error' => $errors->first('password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'password','placeholder' => '********','name' => 'password','id' => 'password','label' => 'Contraseña:','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('password'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                    <!-- /password -->

                    <!-- password -->
                    <?php if (isset($component)) { $__componentOriginal4fb6044c7ed6b655352043ff774efcd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.input','data' => ['type' => 'password','placeholder' => '********','name' => 'password_confirmation','id' => 'password_confirmation','label' => 'Confirmar contraseña:']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'password','placeholder' => '********','name' => 'password_confirmation','id' => 'password_confirmation','label' => 'Confirmar contraseña:']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $attributes = $__attributesOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__attributesOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0)): ?>
<?php $component = $__componentOriginal4fb6044c7ed6b655352043ff774efcd0; ?>
<?php unset($__componentOriginal4fb6044c7ed6b655352043ff774efcd0); ?>
<?php endif; ?>
                    <!-- /password -->

                    <div class="d-flex align-items-center mt-5">
                      <input type="submit" value="Registrar" class="btn btn-primary me-4">
                      <a href="<?php echo e(route('auth.loginForm')); ?>">Iniciar sesion</a>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- BOOTSTRAP -->
  <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <!-- OWL CAROUSEL -->
  <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
  <!-- SCRIPT -->
  <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
  <!-- SELECT2 -->
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
  <!-- CUSTOM SCRIPT -->
  <script>
    $(document).ready(function () {
      $('#actividad_principal').select2({
        theme: 'bootstrap-5',
        tags: true,
      })

      $('#productos').select2({
        theme: 'bootstrap-5',
        tags: true,
      })

      $('#materias_primas').select2({
        theme: 'bootstrap-5',
        tags: true,
      })

      $('#servicios').select2({
        theme: 'bootstrap-5',
        tags: true,
      })

      $('#afiliados').select2({
        theme: 'bootstrap-5'
      })

      $('#productos').on('select2:select', function (e) {
        const parameter = e.params.data.text

        const newInputProduccionTotalMensual = `
          <div class="row" id="producto-${parameter.toLowerCase().trim().replace(' ', '-')}">
            <div class="col-12">
              <p class="fw-bold text-uppercase text-muted">
                <small>Detalles de ${parameter}</small>
              </p>
            </div>
            <div class="col-lg-4 mb-3">
              <input
                type="number"
                placeholder="Producción total mensual (TM)"
                name="produccion_total_mensual[]"
                class="form-control"
              />
            </div>
            <div class="col-lg-4 mb-3">
              <input
                type="number"
                placeholder=" Porcentaje destinados a exportación"
                name="porcentage_exportacion[]"
                class="form-control"
              />
            </div>
            <div class="col-lg-4 mb-3">
              <input
                type="number"
                placeholder="Mercados de importación / exportación"
                name="mercado_exportacion[]"
                class="form-control"
              />
            </div>
          </div>
        `.trim()

        $('#products_details').append(newInputProduccionTotalMensual)
      })

      $('#productos').on('select2:unselect', function (e) {
        const parameter = e.params.data.text
        console.log(parameter.toLowerCase().trim().replace(' ', '-'))
        $(`#producto-${parameter.toLowerCase().trim().replace(' ', '-')}`).remove()
      });
    })
  </script>
</body>

</html><?php /**PATH C:\laragon\www\avipla\resources\views/auth/register.blade.php ENDPATH**/ ?>