<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
    <div class="sb-sidenav-menu">
        <div class="nav">
            <div class="sb-sidenav-menu-heading">Core</div>
            <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                Dashboard
            </a>
            <div class="sb-sidenav-menu-heading">Administrador</div>
            <?php if(Auth::user()->is_admin): ?>
                <a class="nav-link <?php echo e(request()->routeIs('afiliados.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('afiliados.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-handshake"></i></div>
                    Afiliados
                </a>
                <a class="nav-link <?php echo e(request()->routeIs('invoices.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('invoices.index')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-invoice"></i></div>
                    Facturación
                </a>
                <a
                    class="
                        nav-link
                        <?php echo e(request()->routeIs('noticias.*') || request()->routeIs('categories.*')
                            ? ''
                            : 'collapsed'); ?>

                    "
                    href="#"
                    data-bs-toggle="collapse"
                    data-bs-target="#newsPage"
                    aria-expanded="false"
                    aria-controls="newsPage"
                >
                    <div class="sb-nav-link-icon"><i class="fas fa-newspaper"></i></div>
                    Noticias
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div
                    class="
                        collapse
                        <?php echo e((request()->routeIs('noticias.*') || request()->routeIs('categories.*'))
                            ? 'show'
                            : ''); ?>

                    "
                    id="newsPage"
                    aria-labelledby="headingTwo"
                    data-bs-parent="#sidenavAccordion"
                >
                    <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                        <a href="<?php echo e(route('noticias.index')); ?>" class="nav-link <?php echo e(request()->routeIs('noticias.*') ? 'active' : ''); ?>">Todas las noticias</a>
                        <a href="<?php echo e(route('categories.index')); ?>" class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>">Categorías</a>
                    </nav>
                </div>
                <a
                    class="
                        nav-link
                        <?php echo e(request()->routeIs('users.*') || request()->routeIs('roles.*')
                            ? ''
                            : 'collapsed'); ?>

                    "
                    href="#"
                    data-bs-toggle="collapse"
                    data-bs-target="#usersPage"
                    aria-expanded="false"
                    aria-controls="usersPage"
                >
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Usuarios
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div
                    class="
                        collapse
                        <?php echo e((request()->routeIs('users.*') || request()->routeIs('roles.*'))
                            ? 'show'
                            : ''); ?>

                    "
                    id="usersPage"
                    aria-labelledby="headingTwo"
                    data-bs-parent="#sidenavAccordion"
                >
                    <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                        <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">Todos los usuarios</a>
                        <a href="<?php echo e(route('roles.index')); ?>" class="nav-link <?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>">Roles</a>
                    </nav>
                </div>
            <?php endif; ?>
            <a class="nav-link" href="<?php echo e(route('notifications.index')); ?>">
                <div class="sb-nav-link-icon"><i class="fas fa-envelope"></i></div>
                Boletines
            </a>
        </div>
    </div>
    <div class="sb-sidenav-footer">
        <div class="small">Logueado como:</div>
        <?php echo e(Auth::user()->name); ?>

    </div>
</nav><?php /**PATH D:\laragon\www\avipla\resources\views/partials/dashboard_nav.blade.php ENDPATH**/ ?>