<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AVIPLA | Iniciar sesión</title>
  <!-- BOOTSTRAP -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <!-- CUSTOM CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">
  <!-- OWL CAROUSEL -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">
  <!-- OWL CAROUSEL THEME -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.css')); ?>">
</head>

<body class="bg-secondary">

  <main class="auth-layout">
    <div class="container my-3">
      <div class="row justify-content-center">
        <div class="col-lg-5 bg-auth rounded" style="background-image: url(<?php echo e(asset('assets/img/botellas3.jpg')); ?>)">
        </div>
        <div class="col-lg-5">
          <div class="card shadow">
            <div class="card-body p-5">
              <div class="text-center mb-4">
                <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="Logo AVIPLA" width="100px">
              </div>

              

              <h1 class="fs-3 text-center text-primary mb-4">Iniciar sesión</h1>

              <form action="<?php echo e(route('auth.login')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- correo -->
                <div class="form-floating mb-3">
                  <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="johndoe@gmail.com">
                  <label for="email">Correo electrónico</label>
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- /correo -->

                <!-- correo -->
                <div class="form-floating mb-3">
                  <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="*******">
                  <label for="password">Contraseña</label>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- /correo -->

                <input type="submit" value="Iniciar sesión" class="btn btn-primary">
              </form>
            </div>
            <div class="card-footer py-4">
              <p class="text-muted m-0 text-center">© 2024 AVIPLA. Todos los derechos reservados.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- BOOTSTRAP -->
  <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <!-- OWL CAROUSEL -->
  <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
  <!-- SWEET ALERT -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <!-- SCRIPT -->
  <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
  <?php if(session('success')): ?>
    <script>
      Swal.fire({
        icon: "success",
        title: "<?php echo e(session('success')); ?>"
      });
    </script>
  <?php endif; ?>
</body>

</html><?php /**PATH D:\laragon\www\avipla\resources\views/auth/login.blade.php ENDPATH**/ ?>