<?php $__env->startSection('title', 'Notificaciones'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="mt-4">Notificaciones</h1>
  <ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Notificaciones</li>
  </ol>
  <div class="mb-4">
    <a href="#" class="btn btn-primary">Crear notificación</a>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avipla\resources\views/notificaciones/index.blade.php ENDPATH**/ ?>