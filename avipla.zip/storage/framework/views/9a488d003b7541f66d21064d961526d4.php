
<?php $__env->startSection('title', 'Roles'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="mt-4">Roles</h1>
  <ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Roles</li>
  </ol>
  <div class="mb-4">
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Crear role</a>
  </div>
  <div class="card">
    <div class="card-body">
      <table class="table table-bordered" id="invoices-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Role</th>
          </tr>
        </thead>
    
        <tbody>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>#<?php echo e($role->id); ?></td>
              <td><?php echo e($role->name); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avipla\resources\views/roles/index.blade.php ENDPATH**/ ?>