<div class="mb-3">
    <input
        type="<?php echo e($type); ?>"
        placeholder="<?php echo e($placeholder); ?>"
    >
</div><?php /**PATH D:\laragon\www\avipla\resources\views/components/input.blade.php ENDPATH**/ ?>