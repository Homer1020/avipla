<p class="fw-bold text-uppercase text-muted">Productos y servicios</p>

<div class="mb-3 mb-3">
  <label for="productos" class="form-label">Linea de productos</label>
  <select
    multiple
    class="form-select w-100 <?php $__errorArgs = ['productos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    name="productos[]"
    id="productos"
    data-placeholder="Seleccione uno o varios productos"
  >
    <option></option>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option
        <?php echo e(in_array($producto->id, old('productos', $afiliado->productos ? $afiliado->productos->pluck(['id'])->all() : [])) ? 'selected' : ''); ?>

        value="<?php echo e($producto->id); ?>"
      >
        <?php echo e($producto->nombre); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['productos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div id="products_details">
  <?php $__currentLoopData = old('productos', $afiliado->productos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row" id="producto-<?php echo e(strtolower($productos->find($producto)->nombre)); ?>">
      <div class="col-12">
        <p class="fw-bold text-uppercase text-muted">
          <small>Detalles de <?php echo e($productos->find($producto)->nombre); ?></small>
        </p>
      </div>
      <div class="col-lg-4 mb-3">
        <input
          type="number"
          placeholder="Producción total mensual (TM)"
          name="produccion_total_mensual[]"
          class="form-control <?php $__errorArgs = ["produccion_total_mensual.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
          value="<?php echo e(old('produccion_total_mensual') ? old('produccion_total_mensual')[$key] : $producto->pivot->produccion_total_mensual); ?>"
        />
        <?php $__errorArgs = ["produccion_total_mensual.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-lg-4 mb-3">
        <input
          type="number"
          placeholder="Porcentaje destinados a exportación"
          name="porcentage_exportacion[]"
          class="form-control <?php $__errorArgs = ["porcentage_exportacion.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
          value="<?php echo e(old('porcentage_exportacion') ? old('porcentage_exportacion')[$key] : $producto->pivot->porcentage_exportacion); ?>"
        />
        <?php $__errorArgs = ["porcentage_exportacion.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="col-lg-4 mb-3">
        <input
          type="number"
          placeholder="Mercados de importación / exportación"
          name="mercado_exportacion[]"
          class="form-control <?php $__errorArgs = ["mercado_exportacion.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
          value="<?php echo e(old('mercado_exportacion') ? old('mercado_exportacion')[$key] : $producto->pivot->mercado_exportacion); ?>"
        />
        <?php $__errorArgs = ["mercado_exportacion.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="mb-3 mb-3">
  <label for="materias_primas" class="form-label">Principales materias primas utilizadas</label>
  <select
    multiple
    class="form-select w-100 <?php $__errorArgs = ['materias_primas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    name="materias_primas[]"
    id="materias_primas"
    data-placeholder="Seleccione una o varias materias primas"
  >
    <option></option>
    <?php $__currentLoopData = $materias_primas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia_prima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option
        <?php echo e(in_array($materia_prima->id, old('materias_primas', $afiliado->materias_primas ? $afiliado->materias_primas->pluck(['id'])->all() : [])) ? 'selected' : ''); ?>

        value="<?php echo e($materia_prima->id); ?>"
      ><?php echo e($materia_prima->materia_prima); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

<div class="mb-3">
  <label for="servicios" class="form-label">Servicios prestados</label>
  <select
    multiple
    class="form-select w-100 <?php $__errorArgs = ['servicios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    name="servicios[]"
    id="servicios"
    data-placeholder="Seleccione uno o varios servicios"
  >
    <option></option>
    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option
        <?php echo e(in_array($servicio->id, old('servicios', $afiliado->servicios ? $afiliado->servicios->pluck(['id'])->all() : [])) ? 'selected' : ''); ?>

        value="<?php echo e($servicio->id); ?>"
      ><?php echo e($servicio->nombre_servicio); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['servicios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="mb-3">
  <label for="afiliados" class="form-label">Empresas asociadas a AVIPLA que la refieren</label>
  <select
    multiple
    class="form-select w-100 <?php $__errorArgs = ['afiliados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
    name="afiliados[]"
    id="afiliados"
    data-placeholder="Seleccione uno o varios afiliados"
  >
    <option></option>
    <?php $__currentLoopData = $afiliados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option
        <?php echo e(in_array($referencia->id, old('afiliados', $afiliado->referencias ? $afiliado->referencias->pluck(['id'])->all() : [])) ? 'selected' : ''); ?>

        value="<?php echo e($referencia->id); ?>">
        <?php echo e($referencia->razon_social); ?>

      </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <?php $__errorArgs = ['afiliados'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH D:\laragon\www\avipla\resources\views/afiliados/form/products.blade.php ENDPATH**/ ?>