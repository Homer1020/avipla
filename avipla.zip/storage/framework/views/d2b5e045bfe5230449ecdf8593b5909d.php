<?php $__env->startSection('title', 'Detalle Factura'); ?>
<?php $__env->startSection('content'); ?>
  <h1 class="mt-4">Detalle Factura</h1>
  <ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('invoices.index')); ?>">Facturas</a></li>
    <li class="breadcrumb-item active">Detalle Factura</li>
  </ol>
  
  <div class="row">
      <div class="col-lg-6">
        <p class="fw-bold text-uppercase text-muted">Datos de factura</p>
        <ul class="list-group">
            <li class="list-group-item">
                <span class="fw-bold">Código:</span>
                #<?php echo e($invoice->numero_factura); ?>

            </li>
            <li class="list-group-item">
                <span class="fw-bold">Fecha de emisión:</span>
                <?php echo e($invoice->created_at); ?>

            </li>
            <li class="list-group-item">
                <span class="fw-bold">Monto total:</span>
                <?php echo e($invoice->monto_total); ?>$
            </li>
            <li class="list-group-item">
                <span class="fw-bold">Documento:</span>
                <a target="_blank" href="<?php echo e(route('files.getFile', ['dir' => 'invoices', 'path' => $invoice->documento])); ?>"><?php echo e($invoice->documento); ?></a>
            </li>
            <li class="list-group-item">
                <span class="fw-bold">Estado:</span>
                <span class="badge bg-warning">
                    <?php echo e($invoice->estado); ?>

                </span>
            </li>
        </ul>
    </div>
    <div class="col-lg-6">
        <p class="fw-bold text-uppercase text-muted">Usuario emisor</p>
        <ul class="list-group mb-4">
            <li class="list-group-item">
                <span class="fw-bold">Nombre:</span>
                <?php echo e($invoice->user->name); ?>

            </li>
            <li class="list-group-item">
                <span class="fw-bold">Correo:</span>
                <a href="mailto:<?php echo e($invoice->user->email); ?>"><?php echo e($invoice->user->email); ?></a>
            </li>
        </ul>

        <p class="fw-bold text-uppercase text-muted">Datos del afiliado</p>
        <ul class="list-group">
            <li class="list-group-item">
                <span class="fw-bold">Empresa:</span>
                <?php echo e($invoice->afiliado->razon_social); ?>

            </li>
            <li class="list-group-item">
                <span class="fw-bold">Correo:</span>
                <a href="mailto:<?php echo e($invoice->afiliado->user->email); ?>"><?php echo e($invoice->afiliado->user->email); ?></a>
            </li>
        </ul>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\avipla\resources\views/invoices/show.blade.php ENDPATH**/ ?>