<?php

namespace Database\Seeders;

use App\Models\Servicio;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ServicioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Servicio::insert([
            ['nombre_servicio' => 'Desarrollo web'],
            ['nombre_servicio' => 'Diseño de interiores'],
        ]);
    }
}
